using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//To consruct enemies of different levels
[System.Serializable]
public class Wave
{
    public GameObject enemyPrefeb;
    public int count;
    public float rate;
    
}
